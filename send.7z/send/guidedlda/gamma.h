#ifndef LDA_GAMMA_H_
#define LDA_GAMMA_H_

double lda_lgamma(double);

#endif
